clc;
clear all;
close all;
%%
Input_Image=imread('D:\NITPY PhD\My_Phd_Work\DTP_Net\DTP-Net_Code_Uploaded\Demo_DTP-Net\Test_Images\50_Img.jpg');
imshow(Input_Image)
Ground_Truth=imread('D:\NITPY PhD\My_Phd_Work\DTP_Net\DTP-Net_Code_Uploaded\Demo_DTP-Net\Test_Gt\50_Msk.png');
imshow(Ground_Truth)
%%%Convert the input image from RGB colour space to Gray scale%%%
Gray_Image = rgb2gray(Input_Image);
imshow(Gray_Image)
%%
load("DTPNet_Pretrained_Model.mat")
Gray_Image_Resize= imresize(Gray_Image,[224 224]);
Predicted_Threshold_Value = abs(predict(ccnet,Gray_Image_Resize))
%%
%Threshold_Value=Threshold_Value*255;
Segmented_Output=Gray_Image<Predicted_Threshold_Value;
figure,imshow(Segmented_Output,'Border','tight');
DSI= dice(Segmented_Output,Ground_Truth)

%%%Morphological post-processing (MP) Operation%%%
%%%1. Connected Component Labelling%%%
Labelled_Connected_Components=bwlabel(Segmented_Output);

%%%2. Extract Largest Connected Component%%%
props=regionprops(Labelled_Connected_Components,'Area');
area=[props.Area];  
maxArea=max(area);  
Lesion_Label=find(area==maxArea);  
Lesion=ismember(Labelled_Connected_Components,Lesion_Label);

%%%3. Dilation
se = strel('disk',30);
Lesion = imclose(Lesion,se);

%%%4. Hole Filling%%%
Final_Segmentation=imfill(Lesion,'holes');
figure,imshow(Final_Segmentation,'Border','tight');

%%%Calculate the segmentation accuracy in terms of DSI%%%
DSI_Final = dice(Final_Segmentation,Ground_Truth)